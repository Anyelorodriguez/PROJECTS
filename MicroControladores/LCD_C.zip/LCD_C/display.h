#ifndef __display_H__
#define __display_H__

/* Prototipo de la funcion */
int display(int num_decimal);
void visualizacion(int contador, int delay);

#endif // __display_H__