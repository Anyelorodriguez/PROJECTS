#include<iostream>
#include<stdlib.h>
#include<string.h>
#include<fstream>
#include<windows.h>

using namespace std;

void anadir();
void lectura();
void crear_archivo();
void usuario();
void usuario_lectura();
int Ret();
int Ret_2();

int main()
{
	int i=1,opc;
	crear_archivo();
	usuario();
	
	cout<<"\nMENU"<<"\n1. Ver usuarios conectados."<<"\n2. Chatear"<<"\nDigite la obcion:\n ";
	cin>>opc;
	
	if (opc == 1)
	{
		usuario_lectura();
	}
	else if (opc == 2)
	{
		while (i=1)
		{
			Ret_2();
			Ret();
		}
	}
	system("pause");
	return 0;
};

int Ret()
{
	system("cls");
	lectura();
	anadir();
	Sleep(10000);
};
int Ret_2()
{
	system("cls");
	lectura();
	anadir();
	Sleep(10000);
};
void anadir()
{
	ofstream archivo;
	string texto;
	char rpt;
		
	archivo.open("Chat.txt",ios::app);
		
	if (archivo.fail()){
		cout<<"No se pudo abrir el archivo";
		exit(1);
	}
	do{
		fflush(stdin);
		cout<<"Digite una frase: ";
		getline(cin,texto);
		archivo<<texto<<endl;
		
		cout<<"Desea agregar otra frase? (s/n): ";
		cin>>rpt;
	}while((rpt == 'S') || (rpt == 's'));
		
	archivo.close();
};
void lectura()
{
	ifstream archivo; 
	string texto;
	
	archivo.open("Chat.txt",ios::in);
	
	if (archivo.fail()){
		cout<<"No se pudo abrir el archivo";
		exit(1);
	}
	
	while(!archivo.eof())
	{
		getline(archivo,texto);
		cout<<texto<<endl;
	}
	
	archivo.close();
	
};
void crear_archivo()
{
	ofstream archivo;
			
	archivo.open("Chat.txt",ios::app);
	if (archivo.fail())
	{
		archivo.open("Chat.txt",ios::out);
		exit(1);
    }
	archivo.close(); 
	
};
void usuario()
{
	ofstream archivo;
	string Usuario;
		
	archivo.open("usuario.txt",ios::app);
	if (archivo.fail())
	{
		archivo.open("usuario.txt",ios::out);
		exit(1);
    }
    
		fflush(stdin);
		cout<<"Digite su usuario: ";
		getline(cin,Usuario);
		archivo<<Usuario<<endl;
		    
	archivo.close(); 
};
void usuario_lectura()
{
	ifstream archivo;
	string texto;
	
	archivo.open("usuario.txt",ios::in);
	
	if (archivo.fail()){
		cout<<"No se pudo abrir el archivo";
		exit(1);
	}
	
	while(!archivo.eof())
	{
		getline(archivo,texto);
		cout<<texto<<endl;
	}
	archivo.close();
	
};
